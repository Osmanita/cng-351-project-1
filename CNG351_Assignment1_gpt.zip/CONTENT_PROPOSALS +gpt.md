# İçerik kararları - onaylanan revizyon

K1 ve R1-R5 kullanıcı onayıyla uygulandı. K1 aktif kira tanımı hem StartDate hem EndDate koşulunu içerir. R1 StartTime earlier than EndTime koşulunu korur.

O1 ve O3 uygulanmadı. O2: stored IsCorrect ve tutarlılık kuralı aynen korundu.

## K1 - Eski kiracı şirketleri koru; aktif kira şartını mevcut kiracılarla sınırla

Durum: APPLIED

**CNG351_Assignment1_Report +gpt.pdf - sayfa 13 - UC3 rules 3**

**Eski metin:**

Each Rental links one company to one office with its dates and MonthlyRent. Every company has at least one active rental now. Historical rentals are retained and an office may be empty. Rental intervals for the same office cannot overlap.

**Karar metni / öneri:**

Each Rental links one company to one office and records StartDate, EndDate and MonthlyRent. A rental is ongoing when StartDate is on or before today and EndDate is NULL or later than today. Every company currently operating in KALTEV has at least one ongoing rental. Ended rentals are kept as history, and an office may have no ongoing rental. Rental periods of the same office cannot overlap.

**CNG351_Assignment1_Report +gpt.pdf - sayfa 13 - UC3 assumptions 5**

**Eski metin:**

(new paragraph)

**Karar metni / öneri:**

A company that has left KALTEV stays in the system so that its past rentals remain linked to it. The ongoing-rental rule applies only to companies currently operating in the building.

**CNG351_Assignment1_Chen +gpt.drawio - sayfa 14 - UC3A / text_3**

**Eski metin:**

Each company must have at least one active rental now. Rental intervals for the same office cannot overlap.

**Karar metni / öneri:**

Every company currently operating in KALTEV has at least one ongoing rental. Rental periods of the same office cannot overlap.

**Not:** The approved definition checks both StartDate and EndDate; archived companies retain past rental links. HoldsRental (1,N) is unchanged.

## R1 - Rezervasyon varsayımını aynı gün ve başlangıç anahtarıyla sınırla

Durum: APPLIED

**CNG351_Assignment1_Report +gpt.pdf - sayfa 13 - UC3 assumptions 3**

**Eski metin:**

Bookings take place within one calendar date, with StartTime earlier than EndTime. The stated start-slot uniqueness rule is enforced; a broader interval-overlap prohibition is not inferred from it.

**Karar metni / öneri:**

A booking starts and ends on the same date, with StartTime earlier than EndTime. The key (RoomNumber, BookingDate, StartTime) prevents two bookings for the same room from starting on the same date at the same time.

**Not:** Bu metin daha geniş bir zaman aralığı çakışma yasağını eklemez; anahtar ve cardinality değişmez.

## R2 - Yatırım yapmadan kaydedilebilen Investor varsayımını açıkla

Durum: APPLIED

**CNG351_Assignment1_Report +gpt.pdf - sayfa 13 - UC3 assumptions 4**

**Eski metin:**

An investor may invest in the same company more than once. InvestmentID distinguishes those dated transactions. Investor email is not assumed to be unique.

**Karar metni / öneri:**

An investor may invest in the same company more than once. InvestmentID distinguishes those dated transactions. Investor email is not assumed to be unique. An investor may be registered before making any investment, so Investor participates partially in ProvidedBy.

**Not:** ProvidedBy tarafındaki mevcut Investor (0,N) korunur. Aynı konuda değişecek mevcut draw.io alt notu yoktur; diyagram bu katılımı zaten gösterir.

## R3 - UC1 A4 varsayımını doğrudan HasAttempt total participation ile açıkla

Durum: APPLIED

**CNG351_Assignment1_Report +gpt.pdf - sayfa 4 - UC1 assumptions 4**

**Eski metin:**

The mandatory first question is checked when participation is completed. Temporary pre-answer workflow states are outside the stored completed-play model.

**Karar metni / öneri:**

Every recorded contestant has been asked at least one question, so Contestant participates totally in HasAttempt.

**Not:** HasAttempt tarafındaki mevcut Contestant (1,N) korunur.

## R4 - UC2 model, oda ve allocation kurallarındaki gereksiz current sözcüklerini çıkar

Durum: APPLIED

**CNG351_Assignment1_Report +gpt.pdf - sayfa 8 - UC2 rules 2**

**Eski metin:**

Each machine has exactly one current model and one current laundry room. MinLoad must not exceed MaxLoad; the model records its supported program names.

**Karar metni / öneri:**

Each machine is based on exactly one model and is located in exactly one laundry room. MinLoad must not exceed MaxLoad; the model records its supported program names.

**CNG351_Assignment1_Report +gpt.pdf - sayfa 8 - UC2 rules 3**

**Eski metin:**

Each Machine-Dormitory pair has at most one current allocation, with its own UsageRank and FreeCreditAmount. IsLeadingDorm is true exactly when UsageRank = 1 for that machine.

**Karar metni / öneri:**

Each Machine-Dormitory pair has at most one allocation, with its own UsageRank and FreeCreditAmount. IsLeadingDorm is true exactly when UsageRank = 1 for that machine.

**Not:** UC2A IsLeadingDorm alt notu aynı bilgiyi zaten taşır; model/oda/allocation geçmişi eklenmez.

## R5 - Student.Age açıklamasını sadeleştir; CampusZone hakkındaki gereksiz alt başlık cümlesini çıkar

Durum: APPLIED

**CNG351_Assignment1_Report +gpt.pdf - sayfa 8 - UC2 rules 1**

**Eski metin:**

Machine.Type is standard or industrial. Dormitory.Level is undergraduate or graduate. Student.Username is unique in addition to StudentID. CampusZone and Student.Age are stored attributes.

**Karar metni / öneri:**

Machine.Type is standard or industrial. Dormitory.Level is undergraduate or graduate. Student.Username is unique in addition to StudentID. Student.Age is a stored attribute because no birth date is given.

**CNG351_Assignment1_Chen +gpt.drawio - sayfa 9 - UC2A / text_1**

**Eski metin:**

Chen ERD | Allocation attributes belong to the Machine-Dormitory pair. CampusZone is stored as supplied.

**Karar metni / öneri:**

Chen ERD | Allocation attributes belong to the Machine-Dormitory pair.

**Not:** CampusZone attribute olarak kalır; yalnızca tekrar eden açıklama kaldırılır.

## O1 - Bir yarışmacıya aynı sorunun en fazla bir kez sorulması varsayımını seç

Durum: NOT APPLIED - user instruction

**CNG351_Assignment1_Report +gpt.pdf - sayfa 4 - UC1 assumptions 2**

**Eski metin:**

The same question may be asked to a contestant more than once; separate AttemptNo values distinguish these events. No prohibition of repeated questions is stated.

**Karar metni / öneri:**

A question is asked to the same contestant at most once, but it may be asked to different contestants over time. AttemptNo only records the order of questions within a contestant's game.

**CNG351_Assignment1_Report +gpt.pdf - sayfa 4 - UC1 rules 4**

**Eski metin:**

A completed contestant participation must have at least one QuestionAttempt. AttemptNo values are distinct within a contestant and increase in asking order. GivenAnswer is the submitted slot; the stored IsCorrect value must agree with GivenAnswer = Question.CorrectChoice.

**Karar metni / öneri:**

A completed contestant participation must have at least one QuestionAttempt. AttemptNo values are distinct within a contestant and increase in asking order. GivenAnswer is the submitted slot; the stored IsCorrect value must agree with GivenAnswer = Question.CorrectChoice. A contestant cannot have two QuestionAttempt occurrences for the same question.

**Not:** Yönergenin açıkça istemediği bir uniqueness kuralı ekler. Ekip kararı olmadan uygulanmaz.

## O2 - IsCorrect için stored veya derived yaklaşımını seç

Durum: KEEP EXISTING - approved decision

**Not:** Önerim: mevcut stored IsCorrect (düz oval) ve karşılaştırmayla denetlenen tutarlılık kuralı birlikte kalsın. Stored değer ile consistency constraint çelişmez. Derived seçilecekse UC1B IsCorrect ovali kesikli yapılmalı; UC1 kural 4 ve UC1B text_4 içindeki stored/recorded ifadeleri birlikte değiştirilmelidir. Sadece denetim cümlesini silmek gerekli değildir. Bu madde ayrıca açık seçim gerektirir.

## O3 - Legend içindeki Booking'e özel bilgiyi UC3'e taşı; exporter cümlesini çıkar

Durum: NOT APPLIED - user instruction

**CNG351_Assignment1_Report +gpt.pdf - sayfa 2 - Legend / Dashed underline**

**Eski metin:**

Partial key of a weak entity. BookingDate and StartTime together form Booking's partial key.

**Karar metni / öneri:**

Partial key of a weak entity.

**CNG351_Assignment1_Report +gpt.pdf - sayfa 13 - UC3 rules 7**

**Eski metin:**

There are exactly ten MeetingRoom records. Each booking has one room and one company. The full key (RoomNumber, BookingDate, StartTime) prevents two bookings with the same room, date and start time, while allowing simultaneous starts in different rooms.

**Karar metni / öneri:**

There are exactly ten MeetingRoom records. Each booking has one room and one company. The full key (RoomNumber, BookingDate, StartTime) prevents two bookings with the same room, date and start time, while allowing simultaneous starts in different rooms. BookingDate and StartTime together form Booking's partial key.

**CNG351_Assignment1_Report +gpt.pdf - sayfa 2 - Requirements source paragraph**

**Eski metin:**

The eight vector drawing pages were exported from draw.io.

**Karar metni / öneri:**

(remove sentence)

**Not:** UC3C text_2 zaten Booking partial key bilgisini içerir; bu not korunur.
